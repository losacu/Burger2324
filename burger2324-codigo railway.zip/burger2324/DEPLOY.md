# Cómo publicar Burger 2324

Hay dos formas de publicarlo. Se pueden usar las dos a la vez (por ejemplo, Vercel como demo rápida y Railway como versión real).

| | Vercel (estático) | Railway (completo) |
|---|---|---|
| Sitio con carta, carrito y pedido por WhatsApp | ✅ | ✅ |
| Panel de administración `/admin` | ❌ | ✅ |
| Pedidos registrados en el panel | ❌ | ✅ |
| Cómo se cambia la carta | editando `src/seed-data.js` y volviendo a deployar | desde el panel, al instante |
| Costo | gratis | plan Hobby (~USD 5/mes) o crédito gratis de prueba |

## 0. Subir el código a GitHub (una sola vez)

El proyecto ya es un repositorio git. Crear un repo vacío en GitHub (por ejemplo `burger2324`) y:

```bash
git remote add origin https://github.com/TU-USUARIO/burger2324.git
git push -u origin main
```

## 1. Vercel (versión estática, gratis)

1. Entrar a <https://vercel.com/new> y elegir el repo `burger2324`.
2. Vercel lee `vercel.json` solo: build `npm run build:static`, salida `dist/`. No hay que tocar nada.
3. (Opcional) En **Environment Variables** agregar `SITE_URL` = `https://tu-dominio.com` para que los metadatos de Google y WhatsApp apunten al dominio real.
4. Deploy. Cada `git push` vuelve a generar el sitio.

Para cambiar precios o productos en esta versión: editar `src/seed-data.js`, hacer commit y push. Alternativa cómoda: correr el panel en la compu (`npm start` → `/admin`), editar ahí, y después exportar la carta al seed (ver "Sincronizar" más abajo).

## 2. Railway (versión completa con panel)

1. Entrar a <https://railway.com/new> → **Deploy from GitHub repo** → elegir `burger2324`. Railway usa el `Dockerfile` del proyecto.
2. En el servicio → **Variables**, agregar:

   | Variable | Valor |
   |---|---|
   | `DATA_DIR` | `/data` |
   | `COOKIE_SECURE` | `1` |
   | `ADMIN_USER` | `admin` |
   | `ADMIN_PASSWORD` | una contraseña fuerte (solo se usa la primera vez) |
   | `SITE_URL` | la URL pública, ej. `https://burger2324.up.railway.app` (se puede completar después del primer deploy) |
   | `TZ` | `America/Argentina/Buenos_Aires` |

3. En el servicio → **Volumes** → **Add Volume** → mount path `/data`. **Sin esto, la carta y las fotos se borran en cada deploy.**
4. En **Settings → Networking → Generate Domain** para tener la URL pública. Copiarla en `SITE_URL`.
5. Abrir `https://.../admin`, entrar con el usuario y contraseña de las variables, y cambiar la contraseña desde Cuenta.

Health check: Railway consulta `/healthz`; si responde `ok`, el deploy queda activo.

### Render / Fly.io / VPS con Docker

El mismo `Dockerfile` sirve. Montar un disco persistente en `/data` y definir las mismas variables. En un VPS:

```bash
docker build -t burger2324 .
docker run -d --name burger2324 -p 3000:3000 -v burger2324-data:/data \
  -e COOKIE_SECURE=1 -e SITE_URL=https://tu-dominio.com -e ADMIN_PASSWORD=cambiame burger2324
```

y un proxy con HTTPS adelante (Caddy: `tu-dominio.com { reverse_proxy localhost:3000 }`).

## 3. Sincronizar la carta del panel hacia la versión estática

Si el dueño edita la carta en Railway y también se quiere actualizar la copia de Vercel:

1. Panel → Cuenta → **Descargar backup (JSON)**.
2. Guardarlo como `data/import.json` en la compu y correr `npm run import-backup` (recrea la base local con esa carta).
3. `npm run build:static` genera `dist/` con la carta nueva; o hacer commit de `src/seed-data.js` actualizado con `npm run export-seed`.

## 4. Dominio propio

- Vercel: Settings → Domains → agregar `burger2324.com.ar` y apuntar el DNS como indica.
- Railway: Settings → Networking → Custom Domain, y un registro CNAME en el DNS.
- En los dos casos, poner el dominio final en `SITE_URL` y volver a deployar.

## Checklist antes de mostrárselo al cliente

- [ ] Número de WhatsApp probado desde un celular sin el número agendado (¿lleva el 9? `5492324353266`).
- [ ] Horario real (Instagram dice 20:00, Pency dice 19:30).
- [ ] Costo de envío real (Pency dice $2.500 / $3.000; el sitio tiene $1.500 de ejemplo).
- [ ] Contenido de los combos confirmado.
- [ ] Contraseña del panel cambiada.
- [ ] Texto de "Nosotros" escrito por el dueño.
